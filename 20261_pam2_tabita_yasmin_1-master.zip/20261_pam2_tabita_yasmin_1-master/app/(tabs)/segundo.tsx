import React from 'react';
// Importamos o básico do react-native (essencial para não dar erro de 'não encontrado')
import { ScrollView, StatusBar, StyleSheet, Text, View } from 'react-native';

export default function HomeScreen() {
  return (
    // SafeAreaView ou View para a cor de fundo não vazar
    <View style={styles.background}>
      <StatusBar barStyle="light-content" />
      
      <ScrollView 
        // A "janela" por onde vemos o conteúdo
        style={styles.background} 
        // O "recheio" que realmente rola
        contentContainerStyle={styles.container}
      >
        <Text style={styles.titulo}>ETEC Adolpho Berezin</Text>
        
        <View style={styles.card}>
          <Text style={styles.subtitulo}>2MD2</Text>
          <Text style={styles.descricao}>
            Programador de computadores
          </Text>
        </View>

            <View style={styles.fichaTecnica}>
                 
                  <View style={styles.fichaLinha}>
                    <Text style={styles.fichaHorario}>Horário</Text>
                    <Text style={styles.fichaLabel}>Segunda</Text>
                    <Text style={styles.fichaLabel}>Terça</Text>
                    <Text style={styles.fichaLabel}>Quarta</Text>
                    <Text style={styles.fichaLabel}>Quinta</Text>
                    <Text style={styles.fichaLabel}>Sexta</Text>
                  </View>
        
                 
                  <View style={styles.fichaLinha}>
                    <Text style={styles.fichaHorario}>13:30</Text>
                    <Text style={styles.fichaValor}>Química</Text>
                    <Text style={styles.fichaValor}>Português</Text>
                    <Text style={styles.fichaValor}>MAT</Text>
                    <Text style={styles.fichaValor}>EDF</Text>
                    <Text style={styles.fichaValor}>EDF</Text>
                  </View>
        
                  
                  <View style={styles.fichaLinha}>
                    <Text style={styles.fichaHorario}>14:20</Text>
                    <Text style={styles.fichaValor}>TPA</Text>
                    <Text style={styles.fichaValor}>Química</Text>
                    <Text style={styles.fichaValor}>Português</Text>
                    <Text style={styles.fichaValor}>MAT</Text>
                    <Text style={styles.fichaValor}>EDF</Text>
                  </View>
        
               
                  <View style={styles.fichaLinha}>
                    <Text style={styles.fichaHorario}>15:30</Text>
                    <Text style={styles.fichaValor}>TPA</Text>
                    <Text style={styles.fichaValor}>Inglês</Text>
                    <Text style={styles.fichaValor}>APS</Text>
                    <Text style={styles.fichaValor}>História</Text>
                    <Text style={styles.fichaValor}>Bd</Text>
                  </View>
        
                 
                  <View style={[styles.fichaLinha, { borderBottomWidth: 0 }]}>
                    <Text style={styles.fichaHorario}>16:20</Text>
                    <Text style={styles.fichaValor}>PW1</Text>
                    <Text style={styles.fichaValor}>Inglês</Text>
                    <Text style={styles.fichaValor}>APS</Text>
                    <Text style={styles.fichaValor}>História</Text>
                    <Text style={styles.fichaValor}>Bd</Text>
                  </View>
        
                  <View style={styles.fichaLinha}>
                    <Text style={styles.fichaHorario}>16:20</Text>
                    <Text style={styles.fichaValor}>PW1</Text>
                    <Text style={styles.fichaValor}>Inglês</Text>
                    <Text style={styles.fichaValor}>APS</Text>
                    <Text style={styles.fichaValor}>História</Text>
                    <Text style={styles.fichaValor}>Bd</Text>
                  </View>
        
                  <View style={styles.fichaLinha}>
                    <Text style={styles.fichaHorario}>17:10</Text>
                    <Text style={styles.fichaValor}>PW1</Text>
                    <Text style={styles.fichaValor}>Inglês</Text>
                    <Text style={styles.fichaValor}>APS</Text>
                    <Text style={styles.fichaValor}>História</Text>
                    <Text style={styles.fichaValor}>Bd</Text>
                  </View>
        
                  <View style={styles.fichaLinha}>
                    <Text style={styles.fichaHorario}>18:00</Text>
                    <Text style={styles.fichaValor}>PW1</Text>
                    <Text style={styles.fichaValor}>Inglês</Text>
                    <Text style={styles.fichaValor}>APS</Text>
                    <Text style={styles.fichaValor}>História</Text>
                    <Text style={styles.fichaValor}>Bd</Text>
                  </View>
                  
                  
                </View>

        <Text style={styles.textoFundo}>Arraste para ver mais</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    backgroundColor: '#FF69B4', // Azul Marinho Profundo
  },
  container: {
    // IMPORTANTE: flexGrow permite que o justifyContent funcione no ScrollView
    flexGrow: 1,
    padding: 30,
    alignItems: 'center',
    justifyContent: 'center', // Alinhamento Vertical Central
    gap: 20,
  },
  titulo: {
    color: '#FFF', // Azul ciano brilhante (estilo Tech)
    fontSize: 32,
    fontWeight: 'bold',
    letterSpacing: 2,
    marginBottom: 10,
  },
  card: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)', // Branco transparente
    padding: 20,
    borderRadius: 15,
    width: '100%',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#FFF',
  },
  subtitulo: {
    color: '#FFF',
    fontSize: 20,
    fontWeight: '600',
  },
  descricao: {
    color: '#FFF',
    textAlign: 'center',
    marginTop: 10,
    lineHeight: 22,
  },
  textoFundo: {
    color: '#FFF',
    fontSize: 12,
    marginTop: 20,
    textTransform: 'uppercase',
  },

  fichaTecnica: {
    backgroundColor: '#e7509c',
    width: '100%',
    borderRadius: 12,
    padding: 8,
    borderWidth: 1,
    borderColor: '#ffffff',
  },
  fichaLinha: {
    flexDirection: 'row',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.15)',
  },
  fichaLabel: {
    flex: 1,
    color: 'white',
    fontWeight: 'bold',
    fontSize: 11,
    textAlign: 'center',
  },
  fichaValor: {
    flex: 1,
    color: '#FFF',
    fontSize: 11,
    textAlign: 'center',
  },
  fichaHorario: {
    flex: 1,
    color: '#FFF',
    fontWeight: 'bold',
    fontSize: 11,
    textAlign: 'center',
  }
});
